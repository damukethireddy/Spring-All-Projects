package io.stockgeeks.random.name;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RandomNameServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RandomNameServiceApplication.class, args);
	}

}
