package io.stockgeeks.hello.world.api;

import lombok.Data;

@Data
public class RandomName {

    private String name;
}
